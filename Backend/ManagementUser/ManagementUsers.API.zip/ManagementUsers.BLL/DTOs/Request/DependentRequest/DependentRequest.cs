﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementUsers.BLL.DTOs.Request.DependentRequest
{
    public class DependentRequest
    {
        public long UserId { get; set; }
    }
}
